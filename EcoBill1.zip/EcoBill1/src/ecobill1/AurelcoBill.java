
package ecobill1;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;


public class AurelcoBill extends javax.swing.JFrame {

    
    
  public void printBill() {
    // Create the loading popup
    JDialog loadingDialog = new JDialog(this, "Printing", true);
    JLabel message = new JLabel("Please wait, printing in progress...", SwingConstants.CENTER);
    message.setFont(new Font("Arial", Font.PLAIN, 14));
    loadingDialog.add(message);
    loadingDialog.setSize(300, 100);
    loadingDialog.setLocationRelativeTo(this);
    loadingDialog.setUndecorated(true);

    // Run printing in a new thread to prevent freezing
    new Thread(() -> {
        SwingUtilities.invokeLater(() -> loadingDialog.setVisible(true)); // Show dialog

        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName("Aurelco Electric Bill");

        job.setPrintable((Graphics g, PageFormat pf, int pageIndex) -> {
            if (pageIndex > 0) return Printable.NO_SUCH_PAGE;

            Graphics2D g2d = (Graphics2D) g;
            g2d.translate(pf.getImageableX(), pf.getImageableY());
            getContentPane().printAll(g);  // Safe printing
            return Printable.PAGE_EXISTS;
        });

        if (job.printDialog()) {
            try {
                job.print();
            } catch (PrinterException ex) {
                JOptionPane.showMessageDialog(this, "Printing failed: " + ex.getMessage());
            }
        }

        // Close the popup after printing
        SwingUtilities.invokeLater(() -> loadingDialog.dispose());
    }).start();
}

    /**
     * Creates new form AurelcoBill
     
     * @param name
     * @param prevReading
     * @param presentReading
     * @param kwhUsed
     * @param totalAmount
     * @param periodFrom
     * @param periodTo
     */
    
    public void setBillData( String name, String prevReading, String presentReading, String kwhUsed, String totalAmount, String periodFrom, String periodTo) {
    Font courierFont = new Font("Courier New", Font.PLAIN, 12);  // You can change size (12) or style

    jTextField1.setFont(courierFont);
    PreviousReading.setFont(courierFont);
    PresentReading.setFont(courierFont);
    KWHused.setFont(courierFont);
    TotalAmount.setFont(courierFont);
    PeriodCoverFrom.setFont(courierFont);
    PeriodCoverTo.setFont(courierFont);

    jTextField1.setText(name);  // Assuming jTextField1 is for Name
    PreviousReading.setText(prevReading);
    PresentReading.setText(presentReading);
    KWHused.setText(kwhUsed);
    TotalAmount.setText(totalAmount);
    PeriodCoverFrom.setText(periodFrom);
    PeriodCoverTo.setText(periodTo);
    
    generateBillBreakdown(name, totalAmount, periodFrom, periodTo);
}
    
   private void generateBillBreakdown(String name, String totalAmountStr, String from, String to) {
    try {
        double total = Double.parseDouble(totalAmountStr);
        
        // Generation and Energy Charges (35% of total)
        double generationCharge = total * 0.20;
        double energyCharge = total * 0.15;
        
        // Transmission Charges (10% of total)
        double transmissionCharge = total * 0.08;
        double ancillaryServiceCharge = total * 0.02;
        
        // Distribution Charges (25% of total)
        double distributionSystemCharge = total * 0.12;
        double distributionDemandCharge = total * 0.08;
        double supplySystemCharge = total * 0.03;
        double meteringCharge = total * 0.02;
        
        // Universal Charges (8% of total)
        double missionaryElectrification = total * 0.02;
        double environmentalCharge = total * 0.015;
        double strandedContractCosts = total * 0.02;
        double strandedDebtRecovery = total * 0.015;
        double npcStrandedDebt = total * 0.01;
        
        // Government Subsidies and Charges (7% of total)
        double lifeline = total * 0.02;
        double seniorCitizenSubsidy = total * 0.015;
        double universalChargeEC = total * 0.01;
        double feed_inTariff = total * 0.025;
        
        // System Charges (5% of total)
        double systemLoss = total * 0.03;
        double realTimeDispatch = total * 0.02;
        
        // Taxes (15% of total)
        double vat = total * 0.12;
        double franchiseTax = total * 0.015;
        double businessTax = total * 0.015;
        
        StringBuilder sb = new StringBuilder();
        sb.append("ECOBILL - DETAILED BREAKDOWN\n");
        sb.append("=========================================\n");
        sb.append("Consumer: ").append(name).append("\n");
        sb.append("Period: ").append(from).append(" to ").append(to).append("\n\n");
        
        // Generation and Energy
        sb.append("GENERATION & ENERGY CHARGES:\n");
        sb.append("Generation Charge:           ₱").append(String.format("%8.2f", generationCharge)).append("\n");
        sb.append("Energy Charge:               ₱").append(String.format("%8.2f", energyCharge)).append("\n");
        sb.append("Sub-total:                   ₱").append(String.format("%8.2f", generationCharge + energyCharge)).append("\n\n");
        
        // Transmission
        sb.append("TRANSMISSION CHARGES:\n");
        sb.append("Transmission Charge:         ₱").append(String.format("%8.2f", transmissionCharge)).append("\n");
        sb.append("Ancillary Service Charge:    ₱").append(String.format("%8.2f", ancillaryServiceCharge)).append("\n");
        sb.append("Sub-total:                   ₱").append(String.format("%8.2f", transmissionCharge + ancillaryServiceCharge)).append("\n\n");
        
        // Distribution
        sb.append("DISTRIBUTION CHARGES:\n");
        sb.append("Distribution System Charge:  ₱").append(String.format("%8.2f", distributionSystemCharge)).append("\n");
        sb.append("Distribution Demand Charge:  ₱").append(String.format("%8.2f", distributionDemandCharge)).append("\n");
        sb.append("Supply System Charge:        ₱").append(String.format("%8.2f", supplySystemCharge)).append("\n");
        sb.append("Metering Charge:             ₱").append(String.format("%8.2f", meteringCharge)).append("\n");
        sb.append("Sub-total:                   ₱").append(String.format("%8.2f", 
            distributionSystemCharge + distributionDemandCharge + supplySystemCharge + meteringCharge)).append("\n\n");
        
        // Universal Charges
        sb.append("UNIVERSAL CHARGES:\n");
        sb.append("Missionary Electrification:  ₱").append(String.format("%8.2f", missionaryElectrification)).append("\n");
        sb.append("Environmental Charge:        ₱").append(String.format("%8.2f", environmentalCharge)).append("\n");
        sb.append("Stranded Contract Costs:     ₱").append(String.format("%8.2f", strandedContractCosts)).append("\n");
        sb.append("Stranded Debt Recovery:      ₱").append(String.format("%8.2f", strandedDebtRecovery)).append("\n");
        sb.append("NPC Stranded Debt:           ₱").append(String.format("%8.2f", npcStrandedDebt)).append("\n");
        sb.append("Sub-total:                   ₱").append(String.format("%8.2f", 
            missionaryElectrification + environmentalCharge + strandedContractCosts + strandedDebtRecovery + npcStrandedDebt)).append("\n\n");
        
        // Government Subsidies
        sb.append("SUBSIDIES & GOVERNMENT CHARGES:\n");
        sb.append("Lifeline Subsidy:            ₱").append(String.format("%8.2f", lifeline)).append("\n");
        sb.append("Senior Citizen Subsidy:      ₱").append(String.format("%8.2f", seniorCitizenSubsidy)).append("\n");
        sb.append("Universal Charge - EC:       ₱").append(String.format("%8.2f", universalChargeEC)).append("\n");
        sb.append("Feed-in Tariff:              ₱").append(String.format("%8.2f", feed_inTariff)).append("\n");
        sb.append("Sub-total:                   ₱").append(String.format("%8.2f", 
            lifeline + seniorCitizenSubsidy + universalChargeEC + feed_inTariff)).append("\n\n");
        
        // System Charges
        sb.append("SYSTEM CHARGES:\n");
        sb.append("System Loss:                 ₱").append(String.format("%8.2f", systemLoss)).append("\n");
        sb.append("Real Time Dispatch:          ₱").append(String.format("%8.2f", realTimeDispatch)).append("\n");
        sb.append("Sub-total:                   ₱").append(String.format("%8.2f", systemLoss + realTimeDispatch)).append("\n\n");
        
        // Taxes
        sb.append("TAXES:\n");
        sb.append("VAT (12%):                   ₱").append(String.format("%8.2f", vat)).append("\n");
        sb.append("Franchise Tax:               ₱").append(String.format("%8.2f", franchiseTax)).append("\n");
        sb.append("Business Tax:                ₱").append(String.format("%8.2f", businessTax)).append("\n");
        sb.append("Sub-total:                   ₱").append(String.format("%8.2f", vat + franchiseTax + businessTax)).append("\n\n");
        
        sb.append("=========================================\n");
        sb.append("TOTAL AMOUNT DUE:            ₱").append(String.format("%8.2f", total)).append("\n");
        sb.append("=========================================\n");
        
          TextArea.setText(sb.toString());
        TextArea.setForeground(Color.GREEN);
        
    } catch (NumberFormatException e) {
        TextArea.setText("Error: Invalid total amount format.");
    }
}

public AurelcoBill() {
    initComponents();

        

    }
    


public void setGreenText(javax.swing.JTextPane textPane, String message) {
    Style style = textPane.addStyle("GreenStyle", null);
    StyleConstants.setForeground(style, Color.GREEN);

}



    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jTextField1 = new javax.swing.JTextField();
        PreviousReading = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        PresentReading = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        KWHused = new javax.swing.JTextField();
        TotalAmount = new javax.swing.JTextField();
        PeriodCoverTo = new javax.swing.JTextField();
        PeriodCoverFrom = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TextArea = new javax.swing.JTextArea();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel10 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel11 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(618, 760));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 550, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(263, 512, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 8)); // NOI18N
        jLabel2.setText("Name:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, 22));

        jSeparator1.setBackground(new java.awt.Color(0, 204, 51));
        jSeparator1.setForeground(new java.awt.Color(0, 204, 51));
        jPanel2.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, 428, 11));

        jTextField1.setEditable(false);
        jTextField1.setBackground(new java.awt.Color(255, 255, 153));
        jTextField1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jTextField1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel2.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 210, -1));

        PreviousReading.setEditable(false);
        PreviousReading.setBackground(new java.awt.Color(255, 255, 153));
        PreviousReading.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jPanel2.add(PreviousReading, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 52, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel3.setText("Reading:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 34, -1, -1));

        PresentReading.setEditable(false);
        PresentReading.setBackground(new java.awt.Color(255, 255, 153));
        PresentReading.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jPanel2.add(PresentReading, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, 52, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 8)); // NOI18N
        jLabel4.setText("Previous");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 61, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 8)); // NOI18N
        jLabel7.setText("Amount:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 101, -1, -1));

        KWHused.setEditable(false);
        KWHused.setBackground(new java.awt.Color(255, 255, 153));
        KWHused.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jPanel2.add(KWHused, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, 52, -1));

        TotalAmount.setEditable(false);
        TotalAmount.setBackground(new java.awt.Color(255, 255, 153));
        TotalAmount.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jPanel2.add(TotalAmount, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 52, -1));

        PeriodCoverTo.setEditable(false);
        PeriodCoverTo.setBackground(new java.awt.Color(255, 255, 153));
        PeriodCoverTo.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jPanel2.add(PeriodCoverTo, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 110, -1));

        PeriodCoverFrom.setEditable(false);
        PeriodCoverFrom.setBackground(new java.awt.Color(255, 255, 153));
        PeriodCoverFrom.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jPanel2.add(PeriodCoverFrom, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 90, 110, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 8)); // NOI18N
        jLabel8.setText("Period Cover (To)");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 60, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 8)); // NOI18N
        jLabel9.setText("Period Cover (From)");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 8)); // NOI18N
        jLabel6.setText("kWh:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 60, -1, 11));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 8)); // NOI18N
        jLabel5.setText("Present:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, 11));

        TextArea.setEditable(false);
        TextArea.setBackground(new java.awt.Color(255, 255, 153));
        TextArea.setColumns(20);
        TextArea.setFont(new java.awt.Font("Segoe UI", 0, 8)); // NOI18N
        TextArea.setForeground(new java.awt.Color(0, 204, 51));
        TextArea.setRows(5);
        TextArea.setWrapStyleWord(true);
        TextArea.setAutoscrolls(false);
        TextArea.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 204, 0)));
        jScrollPane2.setViewportView(TextArea);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 410, 610));

        jSeparator2.setBackground(new java.awt.Color(0, 204, 51));
        jSeparator2.setForeground(new java.awt.Color(0, 204, 51));
        jPanel2.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 410, 10));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(191, 6, 410, 740));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel10.setText("Paalala:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 48, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextPane1.setEditable(false);
        jTextPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTextPane1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(255, 255, 255)));
        jTextPane1.setFont(new java.awt.Font("Segoe UI", 2, 10)); // NOI18N
        jTextPane1.setText("MAHAL NA KASAPI,\n\nIto po ay nagsisilbing huling babala upang kayo ay magbayad ng konsumo sa kuryente nang maiwasan na maalisan ng serbisyo matapos ang takdang panahon na ibinigay ng ating kooperatiba.\n\nSakaling kayo po ay naputulan ng kuryente, kailangang bayaran munang lahat ang pagkakautang, kasama ang iba pang bayarin gaya ng reconnection fee o multa, bago muling maikabit ang serbisyo ng kuryente.\n\nUgaliin po nating magbayad ng maaga upang maiwasan ang 1.5% na multa o surcharge kada buwan. Sa loob po ng Pitong (7) araw na palugit matapos maibigay ang \"Statement of Accounts\" at hindi pa nakabayad ay maaari na po kayong mapasama sa listahan ng mga puputulan ng serbisyo ng kuryente. Ipinapaalala po sa lahat na ang ating kooperatiba ay namumutol may tao man o wala sa ating tahanan o gusali.\n\nAng pagbabayad po ninyo ng maaga ay malaking tulong po ito sa ating kooperatiba. Siguraduhin po lamang na ang inyong ibabayad ay may katumbas na resibo.\n\nMARAMING SALAMAT po sa inyong pagtangkilik.\nPANGASIWAAN NG ECOBILL");
        jTextPane1.setCaretColor(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(jTextPane1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 180, 590));

        jLabel11.setForeground(new java.awt.Color(0, 204, 51));
        jLabel11.setText("Bill Invoice");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 750, -1, -1));

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/power (1).png"))); // NOI18N
        jLabel1.setText("Ecobill");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 90, 30));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/power (2).png"))); // NOI18N
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 660, 140, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 2, 10)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 0, 0));
        jLabel13.setText("Please disregard this notice if the payment has been made");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 770, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 610, 790));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AurelcoBill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AurelcoBill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AurelcoBill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AurelcoBill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AurelcoBill().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField KWHused;
    private javax.swing.JTextField PeriodCoverFrom;
    private javax.swing.JTextField PeriodCoverTo;
    private javax.swing.JTextField PresentReading;
    private javax.swing.JTextField PreviousReading;
    private javax.swing.JTextArea TextArea;
    private javax.swing.JTextField TotalAmount;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
