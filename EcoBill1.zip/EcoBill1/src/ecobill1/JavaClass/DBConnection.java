package ecobill1.JavaClass;

import java.sql.Connection;
import java.sql.DriverManager;



public class DBConnection {
        private static Connection connection;

    public static Connection getConnection() throws Exception {
        if (connection == null || connection.isClosed()) {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Ensure correct driver
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecobill", "root", ""); // adjust credentials if needed
        }
        return connection;
    }
}

