package ecobill1.JavaClass;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;

public class InvoiceDAO {

    public static boolean invoiceExists(String consumerId) {
        String query = "SELECT 1 FROM invoices WHERE consumer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, consumerId);
            ResultSet rs = stmt.executeQuery();
            return rs.next(); // if there is a row, invoice already exists
        } catch (Exception e) {
            e.printStackTrace();
            return false; // default to false on error
        }
    }

    public static void saveInvoice(String consumerId, String consumerName, double presentReading,
                                   double previousReading, Date periodFrom, Date periodTo,
                                   double kwhUsed, double totalAmount) {
        String insert = "INSERT INTO invoices (consumer_id, consumer_name, present_reading, previous_reading, period_from, period_to, kwh_used, total_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(insert)) {

            stmt.setString(1, consumerId);
            stmt.setString(2, consumerName);
            stmt.setDouble(3, presentReading);
            stmt.setDouble(4, previousReading);
            stmt.setDate(5, periodFrom);
            stmt.setDate(6, periodTo);
            stmt.setDouble(7, kwhUsed);
            stmt.setDouble(8, totalAmount);

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
