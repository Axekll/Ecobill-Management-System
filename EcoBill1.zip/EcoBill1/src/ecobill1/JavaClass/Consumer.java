package ecobill1.JavaClass;

public class Consumer {
    private String id;
    private String name;
   
    private String previousReading;

    public Consumer() {
    }

    public Consumer(String id, String name, String presentReading) {
        this.id = id;
        this.name = name;
        this.previousReading = previousReading;
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPreviousReading() {
        return previousReading;
    }

    public void setPreviousReading(String presentReading) {
        this.previousReading = presentReading;
    }
}
