package ecobill1.JavaClass;

import javax.swing.*;
import java.awt.*;

public class WelcomePanel extends JPanel {

    private final Image backgroundImage;

    public WelcomePanel() {
        setLayout(new BorderLayout());

       
        ImageIcon bgIcon = new ImageIcon(getClass().getResource("/ecobill1/background2.jpg")); // your background image
        backgroundImage = bgIcon.getImage();

       
        JLabel lblTitle = new JLabel("Welcome to EcoBill Manager", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Courier New", Font.BOLD, 28));
        lblTitle.setForeground(Color.GREEN);

       
        ImageIcon icon = new ImageIcon(getClass().getResource("/ecobill1/power (3).png"));
        JLabel imageLabel = new JLabel(icon);
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);

       
        JLabel lblSubtitle = new JLabel("Select a module from the left panel to get started.", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.ITALIC, 16));
        lblSubtitle.setForeground(Color.BLACK);

       
        JPanel centerPanel = new JPanel(new GridLayout(3, 1, 10, 10)); // 3 rows, 10px spacing
        centerPanel.setOpaque(false); // Make panel transparent so background shows through
        centerPanel.add(lblTitle);
        centerPanel.add(imageLabel);
        centerPanel.add(lblSubtitle);

        // Add to main panel
        add(centerPanel, BorderLayout.CENTER);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Draw the background image, scaled to fill the panel
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
