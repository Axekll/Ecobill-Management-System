package ecobill1.JavaClass;

import java.awt.Color;
import java.awt.Component;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class ReminderCellRenderer extends DefaultTableCellRenderer {

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

   @Override
public Component getTableCellRendererComponent(JTable table, Object value,
        boolean isSelected, boolean hasFocus, int row, int column) {

    Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

    // Default background
    cell.setBackground(Color.WHITE);
    cell.setForeground(Color.BLACK);
    cell.setFont(cell.getFont().deriveFont(java.awt.Font.PLAIN));

    try {
        String dueDateStr = table.getValueAt(row, 3).toString(); // Due Date column
        Date dueDate = dateFormat.parse(dueDateStr);
        Date today = new Date();
        long diff = dueDate.getTime() - today.getTime();
        long daysRemaining = diff / (1000 * 60 * 60 * 24);

        // For all columns, color background if needed
        if (daysRemaining < 0) {
            cell.setBackground(new Color(255, 102, 102)); // Red
        } else if (daysRemaining <= 3) {
            cell.setBackground(new Color(255, 255, 153)); // Yellow
        }

        // Special formatting for the Status column
        if (column == 5) {
            String status = table.getValueAt(row, column).toString().toLowerCase();

            if (status.contains("overdue")) {
                cell.setForeground(Color.RED);
                cell.setFont(cell.getFont().deriveFont(java.awt.Font.BOLD));
            } else if (status.contains("due soon")) {
                cell.setForeground(new Color(255, 140, 0)); // Orange
                cell.setFont(cell.getFont().deriveFont(java.awt.Font.BOLD));
            }
        }

    } catch (ParseException e) {
        // Default colors on error
        cell.setBackground(Color.WHITE);
        cell.setForeground(Color.BLACK);
    }

    return cell;
}
}
