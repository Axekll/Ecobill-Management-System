package ecobill1.JavaClass;

import ecobill1.LoginForm;
import javax.swing.SwingUtilities;

public class EcoBill1_Main {
    public static void main(String[] args) {
        // Ensure GUI creation is on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            new LoginForm().setVisible(true); // Change to your login JFrame class name
        });
    }
}
