package ecobill1.JavaClass;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConsumerDirect {

    public static Consumer getConsumerById(String id) {
        Consumer consumer = null;
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/ecobill", "root", "");
            String query = "SELECT * FROM consumers WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                consumer = new Consumer();
                consumer.setId(rs.getString("id"));
                consumer.setName(rs.getString("name"));
                consumer.setPreviousReading(rs.getString("previous_reading")); // adjust name if different in DB
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return consumer;
    }
}
