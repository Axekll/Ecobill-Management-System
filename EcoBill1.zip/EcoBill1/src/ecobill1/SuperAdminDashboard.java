package ecobill1;

import ecobill1.JavaClass.WelcomePanel;
import ecobill1.Panels.PaymentTrackingPanel;
import ecobill1.Panels.InvoiceGenerationPanel;
import ecobill1.Panels.ReportPanel;
import java.awt.CardLayout;
import javax.swing.JOptionPane;


public class SuperAdminDashboard extends javax.swing.JFrame {




    public SuperAdminDashboard() {
        initComponents();

          
        // Create Welcome Panel
WelcomePanel welcomePanel = new WelcomePanel();

ContentPanel.add(welcomePanel, "Welcome");

CardLayout cl = (CardLayout) ContentPanel.getLayout();
cl.show(ContentPanel, "Welcome");


        btnIG.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
        ContentPanel.removeAll();
        ContentPanel.add(new InvoiceGenerationPanel());
        ContentPanel.revalidate();
        ContentPanel.repaint();
    }
});

btnPT.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
        ContentPanel.removeAll();
        ContentPanel.add(new PaymentTrackingPanel());
        ContentPanel.revalidate();
        ContentPanel.repaint();
    }
});


btnAR.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
        ContentPanel.removeAll();
        ContentPanel.add(new ReportPanel());
        ContentPanel.revalidate();
        ContentPanel.repaint();
    }
        });


    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SideBarPanel = new javax.swing.JPanel();
        btnCM = new javax.swing.JButton();
        btnIG = new javax.swing.JButton();
        btnPT = new javax.swing.JButton();
        btnAR = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        ContentPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1380, 768));
        setPreferredSize(new java.awt.Dimension(1380, 768));
        setSize(new java.awt.Dimension(1380, 768));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SideBarPanel.setBackground(new java.awt.Color(0, 51, 51));

        btnCM.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/customer.png"))); // NOI18N
        btnCM.setText("Consumer Management");
        btnCM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCMActionPerformed(evt);
            }
        });

        btnIG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/invoice (1).png"))); // NOI18N
        btnIG.setText("Invoice Generation");
        btnIG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIGActionPerformed(evt);
            }
        });

        btnPT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/payment.png"))); // NOI18N
        btnPT.setText("Payment Tracking");
        btnPT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPTActionPerformed(evt);
            }
        });

        btnAR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/reports1.png"))); // NOI18N
        btnAR.setText("Reports");
        btnAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnARActionPerformed(evt);
            }
        });

        btnLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/logout (2).png"))); // NOI18N
        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/layout (1).png"))); // NOI18N

        javax.swing.GroupLayout SideBarPanelLayout = new javax.swing.GroupLayout(SideBarPanel);
        SideBarPanel.setLayout(SideBarPanelLayout);
        SideBarPanelLayout.setHorizontalGroup(
            SideBarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SideBarPanelLayout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(SideBarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnPT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnIG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCM, javax.swing.GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE))
                .addContainerGap(47, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SideBarPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(132, 132, 132))
        );
        SideBarPanelLayout.setVerticalGroup(
            SideBarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SideBarPanelLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addComponent(btnCM, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(btnIG, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(btnPT, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(btnAR, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(199, 199, 199))
        );

        getContentPane().add(SideBarPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 370, 730));

        ContentPanel.setBackground(new java.awt.Color(255, 255, 255));
        ContentPanel.setLayout(new java.awt.CardLayout());
        getContentPane().add(ContentPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, 1030, 730));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIGActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnIGActionPerformed

    private void btnCMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCMActionPerformed
        ConsumersForm consumersForm = new ConsumersForm(); // Open the ConsumersForm JFrame
        consumersForm.setVisible(true);                   // Make it visible
        this.dispose();

    }//GEN-LAST:event_btnCMActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
    int confirmed = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);

    if (confirmed == JOptionPane.YES_OPTION) {
        // Open LoginForm
        LoginForm login = new LoginForm();
        login.setVisible(true);

        // Close current dashboard
        this.dispose();
    }
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnARActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnARActionPerformed

    private void btnPTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnPTActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SuperAdminDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SuperAdminDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SuperAdminDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SuperAdminDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SuperAdminDashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ContentPanel;
    private javax.swing.JPanel SideBarPanel;
    private javax.swing.JButton btnAR;
    private javax.swing.JButton btnCM;
    private javax.swing.JButton btnIG;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnPT;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
