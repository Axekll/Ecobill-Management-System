package ecobill1;

import ecobill1.JavaClass.DBConnection;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;




public class ConsumersForm extends javax.swing.JFrame {

     
    public ConsumersForm() {
        initComponents();
        setSize(1546,915);
      
BackToDashBoard.setCursor(new Cursor(Cursor.HAND_CURSOR));
BackToDashBoard.setForeground(java.awt.Color.WHITE);

BackToDashBoard.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        dispose(); // Close current form (e.g., ConsumersForm)
        new SuperAdminDashboard().setVisible(true); // Open the dashboard again
    }
});

    
 

    jPanel1.setBackground(new java.awt.Color(0, 102, 102)); 

    // Labels - white color and bold font
    Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
    Color labelColor = Color.WHITE;

    lblName.setFont(labelFont);
    lblName.setForeground(labelColor);

    lblAddress.setFont(labelFont);
    lblAddress.setForeground(labelColor);

    lblContact.setFont(labelFont);
    lblContact.setForeground(labelColor);

    lblSearch.setFont(labelFont);
    lblSearch.setForeground(labelColor);
    
    lblEmail.setFont(labelFont);
    lblEmail.setForeground(labelColor);
    
    lblPreviousReading.setFont(labelFont);
    lblPreviousReading.setForeground(labelColor);

    // Text fields - cleaner font and light background
    Font inputFont = new Font("Segoe UI", Font.PLAIN, 14);
    Color inputBg = new Color(240, 240, 240);

    txtName.setFont(inputFont);
    txtName.setBackground(inputBg);

    txtAddress.setFont(inputFont);
    txtAddress.setBackground(inputBg);

    txtContact.setFont(inputFont);
    txtContact.setBackground(inputBg);

    txtSearch.setFont(inputFont);
    txtSearch.setBackground(inputBg);
    
    txtEmail.setFont(inputFont);
    txtEmail.setBackground(inputBg);

   

    tblConsumers.setRowHeight(25);
    tblConsumers.getTableHeader().setReorderingAllowed(false);

    // Scroll pane border
    jScrollPane2.setBorder(BorderFactory.createLineBorder(new Color(0,0,0), 2));

    // Keep your absolute positions intact — no layout changes.



        
        tblConsumers.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
        int selectedRow = tblConsumers.getSelectedRow();
        if (selectedRow >= 0) {
            txtName.setText(tblConsumers.getValueAt(selectedRow, 1).toString());
            txtAddress.setText(tblConsumers.getValueAt(selectedRow, 2).toString());
            txtContact.setText(tblConsumers.getValueAt(selectedRow, 3).toString());
            txtEmail.setText(tblConsumers.getValueAt(selectedRow, 4).toString());
            txtPreviousReading.setText(tblConsumers.getValueAt(selectedRow, 5).toString()); 
        }
    }
});

TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>((DefaultTableModel) tblConsumers.getModel());
tblConsumers.setRowSorter(sorter);

txtSearch.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) {
        search();
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        search();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        search();
    }

    public void search() {
        String keyword = txtSearch.getText().trim();
        if (keyword.length() == 0) {
            sorter.setRowFilter(null); // show all rows if empty
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)^" + Pattern.quote(keyword), 0, 1, 2, 3, 4, 5));
        }

    }
});

        loadConsumers();
    }
    
public boolean isValidEmail(String email) {
    String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
    return email.matches(regex);
}



public void loadConsumers() {
    DefaultTableModel model = (DefaultTableModel) tblConsumers.getModel();
    model.setRowCount(0); // Clear existing rows

    try {
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT id, name, address, contact, email, previous_reading FROM consumers";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("address"),
                rs.getString("contact"),
                rs.getString("email"),
                rs.getString("previous_reading") // assuming this is stored as a string or numeric
            });
        }

        rs.close();
        pst.close();
        conn.close();

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to load consumers.");
    }
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblConsumers = new javax.swing.JTable();
        lblName = new javax.swing.JLabel();
        lblAddress = new javax.swing.JLabel();
        lblContact = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        txtAddress = new javax.swing.JTextField();
        txtContact = new javax.swing.JTextField();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        txtSearch = new javax.swing.JTextField();
        lblSearch = new javax.swing.JLabel();
        BackToDashBoard = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtPreviousReading = new javax.swing.JTextField();
        lblPreviousReading = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(203, 220, 220));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblConsumers.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Address", "Contact", "Email", "Meter Reading"
            }
        ));
        jScrollPane2.setViewportView(tblConsumers);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(451, 189, 818, 445));

        lblName.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/profile.png"))); // NOI18N
        lblName.setText("Name:");
        jPanel1.add(lblName, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 250, 90, 30));

        lblAddress.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/address1.png"))); // NOI18N
        lblAddress.setText("Address:");
        jPanel1.add(lblAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 299, 90, 30));

        lblContact.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/contact1.png"))); // NOI18N
        lblContact.setText("Contact:");
        jPanel1.add(lblContact, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 352, 90, 30));
        jPanel1.add(txtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 246, 304, 38));
        jPanel1.add(txtAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 296, 304, 37));

        txtContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContactActionPerformed(evt);
            }
        });
        jPanel1.add(txtContact, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 345, 304, 37));

        btnAdd.setBackground(new java.awt.Color(51, 153, 0));
        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        jPanel1.add(btnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 570, 70, 50));

        btnUpdate.setBackground(new java.awt.Color(51, 204, 0));
        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        jPanel1.add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 570, -1, 50));

        btnDelete.setBackground(new java.awt.Color(204, 0, 0));
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        jPanel1.add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 570, -1, 50));

        btnClear.setBackground(new java.awt.Color(0, 204, 255));
        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });
        jPanel1.add(btnClear, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 570, -1, 50));
        jPanel1.add(txtSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 140, 336, 32));

        lblSearch.setText("Search");
        jPanel1.add(lblSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 150, -1, -1));

        BackToDashBoard.setText("Back to Dashboard");
        BackToDashBoard.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(255, 255, 255)));
        jPanel1.add(BackToDashBoard, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 650, -1, -1));
        jPanel1.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 400, 304, 35));

        lblEmail.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/Gmail.png"))); // NOI18N
        lblEmail.setText("Email:");
        jPanel1.add(lblEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 410, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/consumer-behavior.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 70, -1, -1));

        jLabel2.setFont(new java.awt.Font("Book Antiqua", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 204, 204));
        jLabel2.setText("Consumer Management");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 30, -1, -1));

        txtPreviousReading.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPreviousReadingActionPerformed(evt);
            }
        });
        jPanel1.add(txtPreviousReading, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 490, 310, 40));

        lblPreviousReading.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/electric-meter.png"))); // NOI18N
        lblPreviousReading.setText("Meter Reading");
        jPanel1.add(lblPreviousReading, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 460, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/background2.jpg"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1360, 720));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -1, 1360, 740));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
            int selectedRow = tblConsumers.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a consumer to update.");
        return;
    }

    int id = (int) tblConsumers.getValueAt(selectedRow, 0);
    String name = txtName.getText();
    String address = txtAddress.getText();
    String contact = txtContact.getText();
    String email = txtEmail.getText();
    String previousReading = txtPreviousReading.getText();
    

    try {
        Connection conn = DBConnection.getConnection();
        String sql = "UPDATE consumers SET name=?, address=?, email=?, contact=?, previous_reading=? WHERE id=?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, name);
        pst.setString(2, address);
        pst.setString(3, email);
        pst.setString(4, contact);
        pst.setString(5, previousReading);
        pst.setInt(6, id);
        pst.executeUpdate();

        JOptionPane.showMessageDialog(this, "Consumer updated successfully!");
        loadConsumers();
        
                // Clear text fields
        txtName.setText("");
        txtAddress.setText("");
        txtContact.setText("");
        txtEmail.setText("");
        txtPreviousReading.setText("");

    } catch (Exception e) {
        e.printStackTrace();
    }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
    String name = txtName.getText().trim();
    String address = txtAddress.getText().trim();
    String contact = txtContact.getText().trim();
    String email = txtEmail.getText().trim();
    String previousReading = txtPreviousReading.getText().trim();
    
    if (!isValidEmail(email)) {
    JOptionPane.showMessageDialog(null, "Invalid email address!", "Error", JOptionPane.ERROR_MESSAGE);
    return; // stop the process
}

    if (name.isEmpty() || address.isEmpty() || email.isEmpty() || contact.isEmpty() || previousReading.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please enter consumer information in all fields!", "Missing Data", JOptionPane.WARNING_MESSAGE);
        return;
    }

    try {
        Connection conn = DBConnection.getConnection();
        String sql = "INSERT INTO consumers (name, address, email, contact, previous_reading) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, name);
        pst.setString(2, address);
        pst.setString(3, email);
        pst.setString(4, contact);
        pst.setString(5, previousReading);
        pst.executeUpdate();
        JOptionPane.showMessageDialog(null, "Consumer added successfully!");

        // Clear fields after successful insertion
        txtName.setText("");
        txtAddress.setText("");
        txtContact.setText("");
        txtEmail.setText("");
        txtPreviousReading.setText("");

        loadConsumers(); // Refresh table
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error adding consumer. Please try again.");
    }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
           int selectedRow = tblConsumers.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a consumer to delete.");
        return;
    }

    int id = (int) tblConsumers.getValueAt(selectedRow, 0);

    int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this consumer?", "Confirm", JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) return;

    try {
        Connection conn = DBConnection.getConnection();
        String sql = "DELETE FROM consumers WHERE id=?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, id);
        pst.executeUpdate();

        JOptionPane.showMessageDialog(this, "Consumer deleted successfully!");
        loadConsumers();
        
                // Clear text fields
        txtName.setText("");
        txtAddress.setText("");
        txtContact.setText("");
        txtEmail.setText("");
        txtPreviousReading.setText("");

    } catch (Exception e) {
        e.printStackTrace();
    }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
    txtName.setText("");
    txtAddress.setText("");
    txtEmail.setText("");
    txtContact.setText("");
    txtPreviousReading.setText("");
    tblConsumers.clearSelection();
    }//GEN-LAST:event_btnClearActionPerformed

    private void txtContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContactActionPerformed

    private void txtPreviousReadingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPreviousReadingActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPreviousReadingActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsumersForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsumersForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsumersForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsumersForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsumersForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BackToDashBoard;
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblAddress;
    private javax.swing.JLabel lblContact;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblPreviousReading;
    private javax.swing.JLabel lblSearch;
    private javax.swing.JTable tblConsumers;
    private javax.swing.JTextField txtAddress;
    private javax.swing.JTextField txtContact;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPreviousReading;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
