package ecobill1.Panels;

import ecobill1.JavaClass.ReminderCellRenderer;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.sql.Statement;


public class ReportPanel extends javax.swing.JPanel {


private Image backgroundImage = new ImageIcon(getClass().getResource("/ecobill1/background.jpg")).getImage();

 
    public ReportPanel() {
        initComponents();
        loadReminders();
        styleTable();
        

        tblReminders.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        ImageIcon bgIcon = new ImageIcon(getClass().getResource("/ecobill1/background.jpg"));
        backgroundImage = bgIcon.getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);

        tblReminders.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        tblReminders.setDefaultRenderer(Object.class, new ReminderCellRenderer());

     
    }

    private void styleTable() {
        tblReminders.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 10));
        tblReminders.getTableHeader().setOpaque(false);
        tblReminders.getTableHeader().setBackground(new Color(32, 212, 194));
        tblReminders.getTableHeader().setForeground(Color.BLACK);

        tblReminders.setRowHeight(30);
        tblReminders.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 10));
        tblReminders.setForeground(Color.DARK_GRAY);

        tblReminders.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                if (isSelected) {
                    c.setBackground(new Color(0, 120, 215));
                    c.setForeground(Color.WHITE);
                } else {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(240, 240, 240));
                    c.setForeground(Color.DARK_GRAY);
                }

                if (column == 6) {
                    String status = (String) table.getValueAt(row, column);
                    if ("Old Payment".equalsIgnoreCase(status)) {
                        c.setForeground(Color.RED.darker());
                        c.setFont(c.getFont().deriveFont(java.awt.Font.BOLD));
                    }
                }

                return c;
            }
        });

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
        tblReminders.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tblReminders.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
        tblReminders.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
    }

  public void loadReminders() {
    String[] columnNames = {
        "Invoice ID", "Consumer ID", "Consumer Name", "Present Reading",
        "Previous Reading", "Period (From)", "Period (To)",
        "kWh Used", "Total Amount", "Payment Date", "Status"
    };

    DefaultTableModel model = new DefaultTableModel(null, columnNames) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/ecobill", "root", "");
         PreparedStatement pst = conn.prepareStatement(
             "SELECT invoice_id, consumer_id, consumer_name, present_reading, previous_reading, period_from, period_to, kwh_used, total_amount, payment_date FROM invoices");
         ResultSet rs = pst.executeQuery()) {

        while (rs.next()) {
            String InvoiceId = rs.getString("invoice_id");
            String consumerId = rs.getString("consumer_id");
            String consumerName = rs.getString("consumer_name");
            double presentReading = rs.getDouble("present_reading");  // changed
            double previousReading = rs.getDouble("previous_reading"); // changed
            Date periodFrom = rs.getDate("period_from");
            Date periodTo = rs.getDate("period_to");
            double kwhUsed = rs.getDouble("kwh_used"); // changed
            double totalAmount = rs.getDouble("total_amount");
            Date paymentDate = rs.getDate("payment_date");

            String status;
            if (paymentDate != null) {
                status = "Paid";
            } else {
                status = "Unpaid";
            }

            model.addRow(new Object[]{
                InvoiceId,
                consumerId,
                consumerName,
                String.format("%.2f", presentReading),   // Format double to 2 decimals for display
                String.format("%.2f", previousReading),  // Format double
                periodFrom.toString(),
                periodTo.toString(),
                String.format("%.2f", kwhUsed),           // Format double
                String.format("₱%.2f", totalAmount),
                (paymentDate != null ? paymentDate.toString() : "N/A"),
                status
            });
        }

        tblReminders.setModel(model);

    } catch (SQLException e) {
        e.printStackTrace();
        javax.swing.SwingUtilities.invokeLater(() -> {
            JOptionPane.showMessageDialog(null,
                "Failed to load reminders from database: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        });
    }
}







    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblReminders = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        lblAlertsReminders = new javax.swing.JLabel();
        btnDelete = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(1200, 730));

        tblReminders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Consumer ID", "Consumer Name", "Present Reading", "Previous Reading", "Period(From)", "Period(To)", "kWh used", "Total Amount", "Payment Date", "Status"
            }
        ));
        jScrollPane1.setViewportView(tblReminders);

        jPanel1.setBackground(new java.awt.Color(32, 212, 194));

        lblAlertsReminders.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblAlertsReminders.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/Panels/report.png"))); // NOI18N
        lblAlertsReminders.setText("Reports");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(420, 420, 420)
                .addComponent(lblAlertsReminders)
                .addContainerGap(646, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblAlertsReminders)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        btnDelete.setBackground(new java.awt.Color(255, 0, 0));
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(473, 473, 473)
                        .addComponent(btnDelete))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 955, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 458, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(95, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed

  int[] selectedRows = tblReminders.getSelectedRows();
DefaultTableModel model = (DefaultTableModel) tblReminders.getModel();

if (model.getRowCount() == 0) {
    JOptionPane.showMessageDialog(this, "No reports to be deleted.", "No Data", JOptionPane.INFORMATION_MESSAGE);
    return;
}

if (selectedRows.length == 0) {
    int confirm = JOptionPane.showConfirmDialog(
        this,
        "No row selected.\nDo you want to delete ALL invoice records?",
        "Confirm Delete All",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.WARNING_MESSAGE
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/ecobill", "root", "");
         Statement stmt = conn.createStatement()) {

        int rowsDeleted = stmt.executeUpdate("DELETE FROM invoices");

        model.setRowCount(0); // clear JTable
        JOptionPane.showMessageDialog(this, rowsDeleted + " record(s) deleted successfully from invoices.", "Success", JOptionPane.INFORMATION_MESSAGE);

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to delete invoices: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    }

} else {
    // Delete selected rows only
    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/ecobill", "root", "")) {
        for (int i = selectedRows.length - 1; i >= 0; i--) {
            String invoiceId = model.getValueAt(selectedRows[i], 0).toString(); // Column 0 = invoice_id

            try (PreparedStatement pst = conn.prepareStatement("DELETE FROM invoices WHERE invoice_id = ?")) {
                pst.setString(1, invoiceId);
                pst.executeUpdate();
            }

            model.removeRow(selectedRows[i]);
        }

        JOptionPane.showMessageDialog(this, "Selected invoice(s) deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to delete selected invoice(s): " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    }
}






    }//GEN-LAST:event_btnDeleteActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDelete;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblAlertsReminders;
    private javax.swing.JTable tblReminders;
    // End of variables declaration//GEN-END:variables
}
