package ecobill1.Panels;
import ecobill1.AurelcoBill;
import ecobill1.JavaClass.Consumer;
import ecobill1.JavaClass.ConsumerDirect;
import ecobill1.JavaClass.InvoiceDAO;
import java.awt.Graphics;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.print.PrinterException;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.awt.print.Printable;
import java.awt.print.PageFormat;
import java.awt.Graphics;
import java.awt.Graphics2D;







public class InvoiceGenerationPanel extends javax.swing.JPanel {

private Image backgroundImage = new ImageIcon(getClass().getResource("/ecobill1/background.jpg")).getImage();



    public InvoiceGenerationPanel() {
        initComponents();
        
     ImageIcon bgIcon = new ImageIcon(getClass().getResource("/ecobill1/background.jpg"));
    backgroundImage = bgIcon.getImage();
    
     tblInvoice.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 10));
    }
    
    @Override
protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
}


              

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtConsumerId = new javax.swing.JTextField();
        txtconsumerName = new javax.swing.JTextField();
        txtKWHUsed = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblKWHUsed = new javax.swing.JLabel();
        btnInvoice = new javax.swing.JButton();
        btnPrint = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btnSearch = new javax.swing.JButton();
        txtPresentReading = new javax.swing.JTextField();
        txtPreviousReading = new javax.swing.JTextField();
        PeriodFrom = new com.toedter.calendar.JDateChooser();
        PeriodTo = new com.toedter.calendar.JDateChooser();
        lblCoveredPeriod = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblInvoice = new javax.swing.JTable();
        btnSave = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(1000, 730));

        txtConsumerId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtConsumerIdActionPerformed(evt);
            }
        });

        txtconsumerName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtconsumerNameActionPerformed(evt);
            }
        });

        txtKWHUsed.setEditable(false);

        jLabel1.setText("Enter ID:");

        jLabel2.setText("Consumer Name:");

        jLabel3.setText("Present Reading:");

        lblKWHUsed.setText("KWH used:");

        btnInvoice.setBackground(new java.awt.Color(0, 204, 255));
        btnInvoice.setText("Generate Invoice");
        btnInvoice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInvoiceActionPerformed(evt);
            }
        });

        btnPrint.setBackground(new java.awt.Color(255, 255, 51));
        btnPrint.setText("Print Invoice");
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(32, 212, 194));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ecobill1/Panels/invoice.png"))); // NOI18N
        jLabel6.setText("Invoice Generation");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(380, 380, 380)
                .addComponent(jLabel6)
                .addContainerGap(390, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jLabel7.setText("Previous Reading:");

        btnSearch.setBackground(new java.awt.Color(0, 255, 255));
        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        lblCoveredPeriod.setText("Period Covered (From)");

        jLabel5.setText("Period Covered (To)");

        jLabel8.setText("Total Amount:");

        tblInvoice.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Consumer Name", "Present Reading", "Previous Reading", "Period Covered (From)", "Period Covered (To)", "KWH used", "Total Amount"
            }
        ));
        jScrollPane2.setViewportView(tblInvoice);

        btnSave.setBackground(new java.awt.Color(0, 255, 0));
        btnSave.setText("Save");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        btnClear.setBackground(new java.awt.Color(255, 0, 0));
        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(500, 500, 500)
                        .addComponent(jLabel1)
                        .addGap(6, 6, 6)
                        .addComponent(txtConsumerId, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearch))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel3)
                                            .addComponent(jLabel7)
                                            .addComponent(lblCoveredPeriod)
                                            .addComponent(jLabel5)
                                            .addComponent(lblKWHUsed)
                                            .addComponent(jLabel8))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtconsumerName, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtPresentReading, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtPreviousReading, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(PeriodFrom, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(PeriodTo, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtKWHUsed, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(14, 14, 14)
                                        .addComponent(btnInvoice)
                                        .addGap(14, 14, 14)
                                        .addComponent(btnSave, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(107, 107, 107)
                                .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 660, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(257, 257, 257)
                                .addComponent(btnPrint, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(2, 2, 2))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtConsumerId, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnSearch))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel1)))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(btnPrint, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblCoveredPeriod)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtconsumerName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtPresentReading, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtPreviousReading, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7))
                                .addGap(18, 18, 18)
                                .addComponent(PeriodFrom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(PeriodTo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtKWHUsed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblKWHUsed))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8)))
                            .addComponent(jLabel5))
                        .addGap(37, 37, 37)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnInvoice, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSave, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(183, 183, 183))
        );
    }// </editor-fold>//GEN-END:initComponents
        
    private void txtConsumerIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtConsumerIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtConsumerIdActionPerformed

    private void txtconsumerNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtconsumerNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtconsumerNameActionPerformed

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrintActionPerformed

  int selectedRow = tblInvoice.getSelectedRow();
if (selectedRow != -1) {
    String name = tblInvoice.getValueAt(selectedRow, 0).toString();
    String prevReading = tblInvoice.getValueAt(selectedRow, 2).toString();
    String presentReading = tblInvoice.getValueAt(selectedRow, 1).toString();
    String kwhUsed = tblInvoice.getValueAt(selectedRow, 5).toString();
    String totalAmount = tblInvoice.getValueAt(selectedRow, 6).toString();
    String periodFrom = tblInvoice.getValueAt(selectedRow, 3).toString();
    String periodTo = tblInvoice.getValueAt(selectedRow, 4).toString();

    // Create the form but do NOT show it
    AurelcoBill aurelcoBill = new AurelcoBill();
    aurelcoBill.setBillData(name, prevReading, presentReading, kwhUsed, totalAmount, periodFrom, periodTo);

    // Prepare printing of the content pane
    PrinterJob job = PrinterJob.getPrinterJob();
    job.setJobName("Aurelco Electric Bill");

    job.setPrintable((Graphics g, PageFormat pf, int pageIndex) -> {
        if (pageIndex > 0) {
            return Printable.NO_SUCH_PAGE;
        }
        
        Graphics2D g2d = (Graphics2D) g;
        g2d.translate(pf.getImageableX(), pf.getImageableY());
        
        // This prints the entire content of the form
        aurelcoBill.getContentPane().printAll(g);
        
        return Printable.PAGE_EXISTS;
    });

    // Show print dialog and print
    boolean doPrint = job.printDialog();
    if (doPrint) {
        try {
            job.print();
        } catch (PrinterException ex) {
            JOptionPane.showMessageDialog(null, "Print failed: " + ex.getMessage());
        }
    }

} else {
    JOptionPane.showMessageDialog(null, "Please select a row to print.");
}


    }//GEN-LAST:event_btnPrintActionPerformed
    
    
    private void btnInvoiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInvoiceActionPerformed
         
  try {
            String name = txtconsumerName.getText().trim();
            String presentReadingStr = txtPresentReading.getText().trim();
            String previousReadingStr = txtPreviousReading.getText().trim();

            // Check if any field is empty BEFORE parsing
            if (name.isEmpty() || presentReadingStr.isEmpty() || previousReadingStr.isEmpty()
                    || PeriodFrom.getDate() == null || PeriodTo.getDate() == null) {
                JOptionPane.showMessageDialog(this, "Please complete all required fields.");
                return;
            }

            // Now it's safe to parse because we already checked for empty strings
            double presentReading;
            double previousReading;
            
            try {
                presentReading = Double.parseDouble(presentReadingStr);
                previousReading = Double.parseDouble(previousReadingStr);
            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(this, "Please enter valid numeric values for readings.");
                return;
            }

            if (presentReading < previousReading) {
                JOptionPane.showMessageDialog(this, "Present reading cannot be less than previous reading.");
                return;
            }

            double kwhUsed = presentReading - previousReading;

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String dateFrom = sdf.format(PeriodFrom.getDate());
            String dateTo = sdf.format(PeriodTo.getDate());

            txtKWHUsed.setText(String.valueOf(kwhUsed));

            double rate = 12.0; // Rate per kWh
            double totalAmount = kwhUsed * rate;

            jTextField1.setText(String.format("%.2f", totalAmount));

            DefaultTableModel model = (DefaultTableModel) tblInvoice.getModel();
            model.addRow(new Object[]{
                name,
                presentReading,
                previousReading,
                dateFrom,
                dateTo,
                kwhUsed,
                String.format("%.2f", totalAmount)
            });

            JOptionPane.showMessageDialog(this, "Invoice generated successfully.");

        } catch (HeadlessException ex) {
            JOptionPane.showMessageDialog(this, "An error occurred while generating the invoice: " + ex.getMessage());
            ex.printStackTrace(); // For debugging purposes
        }
                         




    }//GEN-LAST:event_btnInvoiceActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
                                        

  String id = txtConsumerId.getText().trim();
        
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Consumer ID.");
            return;
        }
        
        try {
            // First, try to get consumer info from Consumer table/class
            Consumer consumer = ConsumerDirect.getConsumerById(id);
            
            if (consumer != null) {
                txtconsumerName.setText(consumer.getName());
                
                // Now check if there are any previous invoices for this consumer
                // Get the latest present reading from invoices table to use as previous reading
                String latestPresentReading = getLatestPresentReading(id);
                
                if (latestPresentReading != null && !latestPresentReading.isEmpty()) {
                    // If there's a previous invoice, use its present reading as the new previous reading
                    txtPreviousReading.setText(latestPresentReading);
                } else {
                    // If no previous invoice exists, use the original previous reading from consumer data
                    txtPreviousReading.setText(consumer.getPreviousReading());
                }
                
            } else {
                JOptionPane.showMessageDialog(this, "Consumer not found.");
                // Clear fields
                txtconsumerName.setText("");
                txtPreviousReading.setText("");
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error searching consumer: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // New method to get the latest present reading from invoices table
    private String getLatestPresentReading(String consumerId) {
        String latestReading = null;
        
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecobill", "root", "");
            
            // Query to get the most recent present reading for this consumer
            String query = "SELECT present_reading FROM invoices WHERE consumer_id = ? ORDER BY invoice_id DESC LIMIT 1";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, consumerId);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                latestReading = rs.getString("present_reading");
            }
            
            rs.close();
            pstmt.close();
            conn.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting latest present reading: " + e.getMessage());
            e.printStackTrace();
        }
        
        return latestReading;
    
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
       try {
            String consumerId = txtConsumerId.getText().trim();
            String consumerName = txtconsumerName.getText().trim();
            String presentReadingStr = txtPresentReading.getText().trim();
            String previousReadingStr = txtPreviousReading.getText().trim();
            
            // Check if fields are empty first
            if (consumerId.isEmpty() || consumerName.isEmpty() || 
                presentReadingStr.isEmpty() || previousReadingStr.isEmpty() ||
                PeriodFrom.getDate() == null || PeriodTo.getDate() == null) {
                JOptionPane.showMessageDialog(this, "Please complete all required fields.");
                return;
            }
            
            // Now safe to parse
            double presentReading;
            double previousReading;
            
            try {
                presentReading = Double.parseDouble(presentReadingStr);
                previousReading = Double.parseDouble(previousReadingStr);
            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(this, "Please enter valid numeric values for readings.");
                return;
            }
            
            java.util.Date periodFrom = PeriodFrom.getDate();
            java.util.Date periodTo = PeriodTo.getDate();

            double kwhUsed = presentReading - previousReading;
            double totalAmount = kwhUsed * 12.0; // Example: fixed rate of P12.00 per kWh

            // Save the invoice (allow multiple invoices for same consumer for different billing periods)
            InvoiceDAO.saveInvoice(consumerId, consumerName, presentReading, previousReading,
                    new java.sql.Date(periodFrom.getTime()), new java.sql.Date(periodTo.getTime()),
                    kwhUsed, totalAmount);

            JOptionPane.showMessageDialog(this, "Invoice generated and saved!");
            
            // Optional: Clear fields after saving
            clearFields();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
         txtConsumerId.setText("");
    txtconsumerName.setText("");
    txtPresentReading.setText("");
    txtPreviousReading.setText("");
    txtKWHUsed.setText("");
    jTextField1.setText(""); // Total Amount field
    
    // Clear date choosers
    PeriodFrom.setDate(null);
    PeriodTo.setDate(null);
    
    // Optional: Show confirmation message
    JOptionPane.showMessageDialog(this, "All fields cleared successfully.");
    
    // Optional: Set focus back to the first field
    txtConsumerId.requestFocus();
    }//GEN-LAST:event_btnClearActionPerformed

 private void clearFields() {
        txtConsumerId.setText("");
        txtconsumerName.setText("");
        txtPresentReading.setText("");
        txtPreviousReading.setText("");
        txtKWHUsed.setText("");
        jTextField1.setText(""); // Total Amount field
        
        // Clear date choosers
        PeriodFrom.setDate(null);
        PeriodTo.setDate(null);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser PeriodFrom;
    private com.toedter.calendar.JDateChooser PeriodTo;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnInvoice;
    private javax.swing.JButton btnPrint;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnSearch;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lblCoveredPeriod;
    private javax.swing.JLabel lblKWHUsed;
    private javax.swing.JTable tblInvoice;
    private javax.swing.JTextField txtConsumerId;
    private javax.swing.JTextField txtKWHUsed;
    private javax.swing.JTextField txtPresentReading;
    private javax.swing.JTextField txtPreviousReading;
    private javax.swing.JTextField txtconsumerName;
    // End of variables declaration//GEN-END:variables
}
